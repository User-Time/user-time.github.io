from http.server import HTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
from exboard import *
import time,json

sound,light,ul=SoundSensor(),PhotosensitiveSensor(),Ultrasound()
rp=[RotaryPotentionmeter(5),RotaryPotentionmeter(6)]

class APIHandler(BaseHTTPRequestHandler):
    def send_json(self,data,status=200):
        body=json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        parsed=urlparse(self.path)
        path,query=parsed.path,parse_qs(parsed.query)
        ts=time.time()
        if path=="/tea/sensors":
            payload={
                "timestamp":ts,
                "light":light.read(),
                "sound":sound.read(),
                "ultrasound":ul.read(),
                "RotaryPotentionmeter":{"0":rp[0].read(),"1":rp[1].read()}
            }
        elif path=="/tea/light":
            payload={
                "timestamp":ts,
                "sensor":"light",
                "light":light.read(),
            }
        elif path=="/tea/sound":
            payload={
                "timestamp":ts,
                "sensor":"sound",
                "sound":sound.read(),
            }
        elif path=="/tea/ultrasound":
            payload={
                "timestamp":ts,
                "sensor":"ultrasound",
                "ultrasound":ul.read(),
            }
        elif path=="/tea/rotary" and "index" in query and query["index"][0].isdigit() and int(query["index"][0])<len(rp):
               idx=int(query["index"][0])
               payload={"timestamp":ts,
                        "sensor":"rotary",
                        "index":idx,
                        "value":rp[idx].read()
               }
        else:
            payload={"timestamp":ts,"status":404,"message":"not found"}
        self.send_json(payload)


server = HTTPServer(("0.0.0.0", 8081), APIHandler)
print("start")
server.serve_forever()
