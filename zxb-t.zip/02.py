# 导入训练箱硬件驱动类：RGB灯环、光敏传感器、声音传感器、通用GPIO引脚
from exboard import RGB, PhotosensitiveSensor, SoundSensor, GPIO
import time   # 导入时间库，用于延时、计时
from datetime import datetime  # 导入日期模块，获取日志的当前时间

# 配置参数
# 手动模式下循环切换的RGB颜色：红、绿、蓝
COLORS = [(255,0,0),(0,255,0),(0,0,255)]

# 硬件初始化
rgb = RGB()# 实例化RGB灯带对象
light = PhotosensitiveSensor()# 实例化光敏传感器
sound = SoundSensor()# 实例化声音传感器
key = GPIO(25, "in")# 设置按键引脚为输入模式
rgb.set([(0,0,0)]*24) # 程序初始化，先将全部灯珠熄灭
sensor26 = GPIO(26, "in") #error test

# 全局状态
# 当前运行模式：auto自动模式 / manual手动模式
mode = "auto"
off_stamp = 0  # 记录手动关闭灯光那一刻的时间戳c
last_led_status = "OFF"  # 记录手动关闭灯光那一刻的时间戳c

# 写入日志函数
def log(log_type, l_val, s_val, status):
    """
    将灯环状态变动信息保存至本地txt日志文件
    :param log_type: 触发事件名称
    :param l_val: 当前光敏传感器数值
    :param s_val: 当前声音传感器数值
    :param status: 灯环当前工作状态
    """
    global last_led_status
     # 如果灯光状态没有发生改变，则不重复记录日志
    if status == last_led_status:
        return
    # 获取格式化后的当前时间
    t = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # 拼装日志文本
    text = f"[{t}] 触发:{log_type} 光照:{l_val} 音量:{s_val} 灯环:{status}\n"
    #  以追加模式写入日志文件led_log.txt
    with open("led_log.txt","a",encoding="utf‑8") as f:
        f.write(text)
    # 在终端打印日志信息
    print(text.strip())
    # 更新上一次灯光状态
    last_led_status = status

try:
    # 程序主循环，循环读取传感器并且执行灯光逻辑c
    while True:
        now = time.time()# 获取当前系统时间戳c
        # ---------- 读取各个传感器数据 ----------
        l_data = light.read()# 读取光敏传感器返回的光照数值c
        s_data = sound.read()# 声音传感器返回元组数据
        sound_val = s_data[1]# 取出元组当中的音量整型数值
        # 传感器异常,进入故障报警流程
        if sensor26.read():
            # 传感器异常报警：1s红、0.5s熄灭，持续5s
            err_start = now
            log("传感器故障",0,0,"故障闪烁")
            print("Sensor Error!")
            # 故障报警持续5秒：1秒红灯亮起，0.5秒熄灭，循环闪烁
            while time.time()-err_start < 5:
                cycle = (time.time()-err_start) % 1.5
                if cycle<1:
                    rgb.set([(255,0,0)]*24)
                else:
                    rgb.set([(0,0,0)]*24)
                time.sleep(0.05)
            # 5秒报警结束之后关闭灯环
            rgb.set([(0,0,0)]*24)
            log("故障恢复",0,0,"自动‑关闭")
            continue

        # 按键检测，按下切换手动开关
        if key.read() == 1:
            time.sleep(0.2)# 延时防抖，规避按键电平抖动
            if mode == "auto":
                 # 当前处于自动模式，按下按键切换成手动模式
                mode = "manual"
                off_stamp = 0
            else:
                if off_stamp == 0:
                    # 手动开灯状态，按下按键关闭灯环
                    rgb.set([(0,0,0)]*24)
                    log("按键关闭",l_data,s_data[1],"手动‑关闭")
                    off_stamp = now
                else:
                    # 手动关灯阶段，再次按下按键重新开启手动彩灯循环
                    off_stamp = 0
            # 等待按键松开，防止多次触发
            while key.read()==1:
                time.sleep(0.01)

        # 手动模式逻辑，优先级最高
        if mode == "manual":
            if off_stamp > 0:
                 # 当前为手动关灯状态，判断5秒计时是否到达
                if now - off_stamp >= 5:
                    mode = "auto"
                    log("手动超时恢复自动",l_data,s_data[1],"自动‑关闭")
            else:
                # 手动开启，每秒切换一次循环彩灯
                c_idx = int(now) % len(COLORS)
                rgb.set([COLORS[c_idx]]*24)
                log("手动颜色循环",l_data,s_data[1],f"手动开启{COLORS[c_idx]}")

        # 自动模式
        else:
            if l_data < 50:
                if sound_val> 100:
                    rgb.set([(0,0,255)]*24)
                    log("暗光检测到声音",l_data,sound_val,"自动‑蓝色常亮")
                else:
                    rgb.set([(0,0,0)]*24)
                    log("暗光无声音",l_data,sound_val,"自动‑关闭")
            else:
                rgb.set([(0,0,0)]*24)
                log("明亮环境",l_data,sound_val,"自动‑关闭")
        time.sleep(0.05) # 循环短暂延时，降低CPU占用

# 捕获键盘Ctrl+C终止程序
except KeyboardInterrupt:
    rgb.set([(0,0,0)]*24)