from exboard import RGB, SoundSensor
import cv2
import numpy as np
import time
from datetime import datetime

# ====================== 【全局参数初始化】【视觉参数完全沿用参考04代码】 ======================
CAM_ID = 0

# -------- 声音传感器业务参数（05任务） --------
SOUND_THRESHOLD = 200
ALARM_BLINK_INTERVAL = 0.5
ALARM_RESET_WAIT = 5.0

# -------- 颜色定义 BGR --------
PURPLE = (255, 0, 255)      # 紫色：手掌轮廓、指尖圆点、指尖连线
BLUE = (255, 0, 0)          # 蓝色：文字
GREEN = (0, 255, 0)         # 绿灯：手掌张开基础灯
RED = (255, 0, 0)           # 红灯：告警闪烁
BLACK = (0, 0, 0)           # 熄灭

# -------- 【原样复制参考04视觉参数，不做修改】 --------
LOWER_SKIN = np.array([0, 10, 60], np.uint8)
UPPER_SKIN = np.array([25, 255, 255], np.uint8)
MAX_HAND_RATIO = 1.5
MIN_HAND_AREA = 1500

# 硬件实例初始化
rgb = RGB()
sound_sensor = SoundSensor()
rgb.set([BLACK] * 24)

# FPS计时变量（沿用参考04）
prev_time = 0

# -------- 05任务状态机全局变量 --------
base_light_state = "off"      # 基础灯光状态 green_on / off
alarm_active = False          # 是否声音告警闪烁
alarm_reset_start = None      # 噪音恢复正常的时间戳，用于5s复位倒计时

# ====================== 日志工具函数（05新增，保存system_log.txt） ======================
def write_log(content: str):
    """写入运行日志，格式 [时间] 内容，追加写入同目录system_log.txt"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{now}] {content}\n"
    try:
        with open("system_log.txt", "a", encoding="utf-8") as f:
            f.write(log_line)
    except Exception as e:
        print(f"日志写入失败:{e}")

# ====================== 【下面视觉工具函数完全复制参考04代码，不修改内部逻辑】 ======================
def get_hand_contour(origin_frame):
    """
    肤色分割 + 长宽比过滤，只识别手掌、过滤长条手臂
    :param origin_frame: 原始BGR图像
    :return: 手部轮廓，找不到返回None
    """
    hsv = cv2.cvtColor(origin_frame, cv2.COLOR_BGR2HSV)
    skin_mask = cv2.inRange(hsv, LOWER_SKIN, UPPER_SKIN)
    skin_mask = cv2.GaussianBlur(skin_mask, (7, 7), 0)
    kernel = np.ones((3, 3), np.uint8)
    skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_CLOSE, kernel)
    skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_OPEN, kernel)

    contours, _ = cv2.findContours(skin_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if len(contours) == 0:
        return None

    valid_hand = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < MIN_HAND_AREA:
            continue
        x, y, w, h = cv2.boundingRect(cnt)
        ratio = max(w, h) / min(w, h)
        if ratio < MAX_HAND_RATIO:
            valid_hand.append(cnt)

    if len(valid_hand) == 0:
        return None
    hand_cont = max(valid_hand, key=cv2.contourArea)
    return hand_cont


def get_fingertips(hand_contour):
    """凸缺陷算法精准提取指尖坐标"""
    hull = cv2.convexHull(hand_contour, returnPoints=False)
    defects = cv2.convexityDefects(hand_contour, hull)
    fingertips = []
    if defects is not None:
        for i in range(defects.shape[0]):
            s, e, f, d = defects[i, 0]
            start = tuple(hand_contour[s][0])
            end = tuple(hand_contour[e][0])
            fingertips.append(list(start))
            fingertips.append(list(end))
    if len(fingertips) <= 0:
        hull_points = cv2.convexHull(hand_contour, returnPoints=True)
        for point in hull_points:
            fingertips.append([point[0][0], point[0][1]])
    return np.array(fingertips)


def draw_hand_connection(img, tip_points):
    """绘制手掌关键点连接线，紫色圆点+连线，原样复用参考代码"""
    for i in range(len(tip_points) - 1):
        p1 = (int(tip_points[i][0]), int(tip_points[i][1]))
        p2 = (int(tip_points[i+1][0]), int(tip_points[i+1][1]))
        cv2.line(img, p1, p2, PURPLE, 2)
    for pt in tip_points:
        cv2.circle(img, (int(pt[0]), int(pt[1])),6,PURPLE,-1)
    return img

# ====================== 主程序循环（融合04视觉 + 05多模态业务） ======================
def main():
    global prev_time, base_light_state, alarm_active, alarm_reset_start
    write_log("===== 手势+声音联动RGB灯环系统启动 =====")

    cap = cv2.VideoCapture(CAM_ID)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
    if not cap.isOpened():
        write_log("异常：摄像头打开失败，请修改CAM_ID")
        print("Camera open failed, please modify CAM_ID")
        return

    gesture_text = "No Hand"
    rgb_status_text = "Off"
    sound_val = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            write_log("警告：读取摄像头帧失败")
            time.sleep(0.05)
            continue

        img_h, img_w = frame.shape[:2]
        frame = cv2.flip(frame,1)
        canvas = frame.copy()

        # 计算FPS（沿用参考04逻辑）
        cur_time = time.time()
        fps = int(1/(cur_time - prev_time))
        prev_time = cur_time

        # -------- 读取声音传感器，增加异常捕获 --------
        try:
            sound_raw = sound_sensor.read()
            sound_val = sound_raw[1]
        except Exception as e:
            write_log(f"异常：声音传感器读取错误 {str(e)}")
            sound_val = 0

        # -------- 手掌识别，完全调用参考04的视觉函数 --------
        hand_cont = get_hand_contour(frame)
        if hand_cont is not None:
            # 绘制手掌紫色轮廓
            cv2.drawContours(canvas,[hand_cont],-1,PURPLE,2)
            tip_array = get_fingertips(hand_cont)
            print(f"Detected fingertips quantity:{len(tip_array)}")

            # 绘制指尖圆点、指尖连接线（参考04绘图逻辑）
            canvas = draw_hand_connection(canvas, tip_array)

            # 手势判定：指尖数量>=3判定手掌张开Open Hand；否则握拳Fist
            if len(tip_array) >= 3:
                gesture_text = "Open Hand"
                base_light_state = "green_on"
            else:
                gesture_text = "Fist"
                base_light_state = "off"
        else:
            gesture_text = "No Hand"
            base_light_state = "off"

        # ================= 声音告警状态机逻辑（05任务核心业务） =================
        # 触发告警条件：基础状态为绿灯，声音>=阈值700
        if base_light_state == "green_on" and sound_val >= SOUND_THRESHOLD:
            if not alarm_active:
                write_log("触发异常声音告警 Abnormal Sound Detected!")
                print("Abnormal Sound Detected!")
                alarm_active = True
                alarm_reset_start = None

        if alarm_active:
            rgb_status_text = "Red Blink Alarm"
            # 非阻塞闪烁：0.5s红，0.5s熄灭
            phase = (cur_time % (ALARM_BLINK_INTERVAL * 2))
            if phase < ALARM_BLINK_INTERVAL:
                led_color = RED
            else:
                led_color = BLACK

            # 噪音下降，启动5秒复位倒计时
            if sound_val < SOUND_THRESHOLD:
                if alarm_reset_start is None:
                    alarm_reset_start = cur_time
                if cur_time - alarm_reset_start >= ALARM_RESET_WAIT:
                    alarm_active = False
                    alarm_reset_start = None
                    write_log("告警结束，恢复基础灯光状态")
            else:
                # 噪音再次超标，重置复位计时器
                alarm_reset_start = None
        else:
            # 无告警，执行手势基础灯光
            if base_light_state == "green_on":
                led_color = GREEN
                rgb_status_text = "Green On"
            else:
                led_color = BLACK
                rgb_status_text = "Off"

        # 握拳/手掌消失，强制关闭告警
        if base_light_state == "off":
            alarm_active = False
            alarm_reset_start = None

        # 设置24颗灯环颜色
        rgb.set([led_color] * 24)

        # -------- 画面绘制文本信息 --------
        info_str = f"Gesture:{gesture_text} | Sound:{sound_val}.dB | RGB:{rgb_status_text}"
        cv2.putText(canvas, info_str, (10,35), cv2.FONT_HERSHEY_SIMPLEX, 0.6, BLUE, 2)
        cv2.putText(canvas, f"FPS:{fps}", (10,65), cv2.FONT_HERSHEY_SIMPLEX,0.5,BLUE,2)

        cv2.imshow("-----", canvas)
        key = cv2.waitKey(1)
        if key == 27:
            write_log("用户按下ESC，程序退出")
            break

    # 资源释放
    cap.release()
    cv2.destroyAllWindows()
    rgb.set([BLACK] * 24)
    write_log("===== 硬件全部释放，程序结束 =====")


if __name__ == "__main__":
    main()