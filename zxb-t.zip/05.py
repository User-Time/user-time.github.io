import cv2

cap = cv2.VideoCapture(
    0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
qr = cv2.QRCodeDetector()
text = ""

while True:
    ret, frame = cap.read()
    if not ret:
        print("摄像头失败")
        break

    data, pts, _ = qr.detectAndDecode(frame)

    if data:
        text = data
        if pts is not None:
            pts = pts.astype(int)
            cv2.polylines(frame, [pts[0]], True, (255, 0, 0), 2)
            x, y = pts[0][0]
            cv2.putText(frame, data, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
    else:
        text = ""
        cv2.putText(frame, "not code", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    cv2.imshow("QRCode Detect", frame)
    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break
    if key == ord("s"):
        cv2.imwrite("qrcode_detect.png", frame)
        with open("qrcode_content.txt", "w", encoding="utf-8") as f:
            if text:
                f.write(text)
                print("保存成功，内容：", text)
            else:
                f.write("当前未识别到二维码")
                print("当前无二维码识别内容")

cap.release()
cv2.destroyAllWindows()