
from exboard import PhotosensitiveSensor
from exboard import RGB
import signal
import sys
import time

rgb = RGB()

sensor3 = PhotosensitiveSensor()

# 全局配置：缓存存储最新12条数据
MAX_SAVE_NUM = 12
data_buffer = []

# Ctrl+C 退出回调函数：关灯 + 写入日志文件
def exit_handle(sign_num, frame):
    print("\n程序接收退出指令，关闭灯环，正在保存光照记录...")
    rgb.set([(0, 0, 0)] * 24)  # 熄灭所有LED
    # 将缓存内12条数据写入light_data.log
    with open("light_data.log", "w", encoding="utf-8") as f:
        for line_data in data_buffer:
            f.write(line_data + "\n")
    print("数据保存完成，程序正常退出")
    sys.exit(0)
    
# 绑定键盘中断信号
signal.signal(signal.SIGINT, exit_handle)

while True:
    
    a3 = sensor3.read()
    # 获取标准时间戳
    now_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print(f"[{now_time}] 光照强度：{a3}")

    # 2、写入缓存，只保留最新12条记录
    record_str = f"[{now_time}] 光照强度：{a3}"
    data_buffer.append(record_str)
    if len(data_buffer) > MAX_SAVE_NUM:
        data_buffer.pop(0)  # 超出容量删掉最旧数据
        
    # 3、分段控制RGB灯环
    if a3 < 90:
         # 小于1/3量程：暖黄色常亮
        rgb.set([(255, 150, 0)] * 24)
    elif a3 >= 90 and a3 <= 180:
        # 1/3 ~ 2/3量程：白色常亮
        rgb.set([(255, 255, 255)] * 24)
    elif a3 >180:
        # 大于2/3量程：紫色1秒闪烁1次（亮1s + 灭1s）
        rgb.set([(255, 0, 255)] * 24)
        time.sleep(1)
        rgb.set([(0, 0, 0)] * 24)

    time.sleep(1)
    

        

