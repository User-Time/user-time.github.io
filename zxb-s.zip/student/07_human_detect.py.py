# -*- coding: utf-8 -*-
"""
附加任务：服务机器人人体感应离岗提醒交互系统开发【修复连续3次采样不触发红灯告警BUG】
硬件资源：
    RGB灯环        : from exboard import RGB
    超声波传感器    : from exboard import Ultrasound
    中间实体按键    : GPIO 26输入模式
修复点：
1.告警触发瞬间立刻点亮红灯，不需要等待闪烁计时
2.增加超声波None异常防护，防止程序崩溃
3.保持按键随时响应，无sleep阻塞
"""
import time
import datetime
import signal

from exboard import RGB
from exboard import Ultrasound
from exboard import GPIO

rgb = RGB()
rgb.set([0, 0, 0] * 24)

us = Ultrasound()
key_gpio = GPIO(26, "in")

# ======================== 参数配置区 ========================
KEY_GPIO_NUM = 26
DISTANCE_THRESHOLD = 30       # cm，小于该距离判定区域有人
NO_HUMAN_TRIGGER_COUNT = 3     # 连续多少次无人采样触发离岗告警
SAMPLE_INTERVAL = 1.0          # 超声波采样周期(秒)
BLINK_INTERVAL = 0.5           # 红灯闪烁亮灭间隔，完整闪烁周期=1s
# ==========================================================

# 业务全局变量
guard_mode = False                  # 值守总开关 False关闭 / True开启
no_human_sample_cnt = 0             # 连续无人采样计数器
alert_log_buffer = []               # 缓存离岗告警，程序退出写入文件
alert_total = 0                     # 拓展：离岗告警总次数统计
last_key_level = 0                  # 按键历史电平，边沿检测消抖

# 非阻塞计时变量
last_sample_time = 0.0              # 上一次超声波采样时间
alert_blink_time = 0.0              # 告警闪烁计时
alert_blink_on = False              # 告警灯状态 True亮 False灭


def safe_exit_handler(signum, frame):
    """捕获 Ctrl + C 中断信号，安全退出处理"""
    print("\n[系统] 接收到Ctrl+C终止信号，执行安全退出流程")
    rgb.set([0, 0, 0] * 24)
    try:
        with open("human_alert.log", "w", encoding="utf-8") as fp:
            for log_line in alert_log_buffer:
                fp.write(log_line + "\n")
        print(f"[系统] 告警日志保存完成，共记录 {len(alert_log_buffer)} 条离岗告警记录")
    except Exception as err:
        print(f"[系统] 日志文件写入失败：{err}")
    exit(0)


signal.signal(signal.SIGINT, safe_exit_handler)

if __name__ == "__main__":
    print("=====人体感应离岗提醒交互系统启动=====")
    print("操作提示：按下中间实体按键(GPIO26)开启/关闭值守模式，随时可切换")

    while True:
        now = time.time()
        # ==========按键检测，无阻塞，随时响应==========
        key_now = key_gpio.read()
        if last_key_level == 0 and key_now == 1:
            time.sleep(0.03)  # 按键消抖
            guard_mode = not guard_mode
            current_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if guard_mode:
                print(f"[{current_ts}] >>> 值守模式【已开启】开始人体距离检测")
                no_human_sample_cnt = 0
                last_sample_time = now
            else:
                print(f"[{current_ts}] >>> 值守模式【已关闭】停止检测，灯环熄灭")
                rgb.set([0, 0, 0] * 24)
                no_human_sample_cnt = 0
            alert_blink_on = False
        last_key_level = key_now

        # 值守关闭状态
        if not guard_mode:
            rgb.set([0, 0, 0] * 24)
            time.sleep(0.01)
            continue

        # ================= 非阻塞超声波采样：每1秒执行一次 =================
        if now - last_sample_time >= SAMPLE_INTERVAL:
            sample_timestamp = datetime.datetime.now()
            dist = us.read()
            last_sample_time = now

            # --------新增：超声波读取异常防护，读到None直接跳过本次采样--------
            if dist is None:
                time_str = sample_timestamp.strftime("%Y-%m-%d %H:%M:%S")
                print(f"[{time_str}] 警告：超声波读取无效，跳过本次采样")
                continue

            if dist < DISTANCE_THRESHOLD:
                # 检测到人：绿色常亮，重置计数，关闭告警闪烁
                no_human_sample_cnt = 0
                rgb.set([0, 255, 0] * 24)
                alert_blink_on = False
                time_str = sample_timestamp.strftime("%Y-%m-%d %H:%M:%S")
                print(f"[{time_str}] 值守在岗 | 检测到人员，距离：{dist} cm")

            else:
                no_human_sample_cnt += 1
                time_str = sample_timestamp.strftime("%Y-%m-%d %H:%M:%S")
                print(f"[{time_str}] 采样无人员 | 连续无人：{no_human_sample_cnt}/{NO_HUMAN_TRIGGER_COUNT}")

                # 达到连续无人阈值触发离岗告警
                if no_human_sample_cnt >= NO_HUMAN_TRIGGER_COUNT:
                    alert_total += 1
                    alert_content = f"离岗告警{alert_total}：值守区域人员离岗，服务缺位提醒"
                    log_text = f"[{time_str}] {alert_content}"
                    alert_log_buffer.append(log_text)
                    print(f"【离岗警告】{log_text}")
                    alert_blink_time = now
                    alert_blink_on = True
                    # =========修复BUG：触发告警立刻点亮红灯=========
                    rgb.set([255, 0, 0] * 24)

        # ================= 非阻塞红灯闪烁逻辑 =================
        if no_human_sample_cnt >= NO_HUMAN_TRIGGER_COUNT:
            if now - alert_blink_time >= BLINK_INTERVAL:
                alert_blink_on = not alert_blink_on
                alert_blink_time = now
                if alert_blink_on:
                    rgb.set([255, 0, 0] * 24)
                else:
                    rgb.set([0, 0, 0] * 24)

        time.sleep(0.01)