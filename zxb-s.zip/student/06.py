# 导入实验箱硬件驱动模块
from exboard import RGB
# 导入时间模块，用于延时、日志时间戳、按键消抖
import time
# 导入超声波传感器类
from exboard import Ultrasound
# 导入GPIO通用引脚驱动，读取实体按键电平
from exboard import GPIO

# 实例化RGB灯环硬件对象
rgb = RGB()
# 按钮1绑定GPIO25，输入模式（预警切换按键）
btn1 = GPIO(25, "in")
# 预留拓展按键2、3（题目拓展功能备用）
btn2 = GPIO(26, "in")
btn3 = GPIO(27, "in")
# 实例化超声波测距传感器
us = Ultrasound()

# 全局：预警总开关，初始状态关闭
warning_switch = False
# 新增核心变量：记录上一轮按键电平，用于识别单次按下动作
last_btn_state = 1
# 拓展：测距、预警日志文件路径
log_path = "distance_warn_log.txt"

# 主循环持续检测硬件状态
while True:
    # 读取当前按钮1实时电平
    current_btn = btn1.read()

    # 仅识别 上一轮松开(1)→当前按下(0) 的下降沿，只切换一次
    if current_btn == 0 and last_btn_state == 1:
        # 消抖延时，过滤硬件电平抖动
        time.sleep(0.05)
        # 二次确认按键依旧按下，才执行切换
        if btn1.read() == 0:
            warning_switch = not warning_switch
            # 记录本次开关切换日志
            log_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            with open(log_path, "a", encoding="utf-8") as log_f:
                if warning_switch:
                    log_f.write(f"[{log_time}] 预警模式手动开启\n")
                else:
                    log_f.write(f"[{log_time}] 预警模式手动关闭\n")
    # 更新上一轮按键状态，供下一轮循环判断
    last_btn_state = current_btn

    # 预警模式开启逻辑
    if warning_switch:
        dist = us.read()
        # 需求3：实时打印预警与距离
        print(f"预警状态：开启 当前距离：{dist}cm")
        # 拓展：写入测距日志
        log_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        with open(log_path, "a", encoding="utf-8") as log_f:
            log_f.write(f"[{log_time}] 实时测距：{dist} cm\n")
        
        # 需求2：距离小于30cm，红灯0.5s闪烁并打印提醒
        if dist < 30:
            rgb.set([(255, 0, 0)] * 24)
            time.sleep(0.5)
            rgb.set([(0, 0, 0)] * 24)
            time.sleep(0.5)
            print("距离过近，请注意！")
    # 预警模式关闭逻辑
    else:
        # 需求1：关闭时熄灭灯、停止测距输出
        rgb.set([(0, 0, 0)] * 24)
        print("预警状态：关闭 当前距离：无检测")
        # 拓展：关闭状态日志记录
        log_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        with open(log_path, "a", encoding="utf-8") as log_f:
            log_f.write(f"[{log_time}] 预警关闭，暂停测距采集\n")

    # 基础循环刷新间隔，和原始代码保持一致
    time.sleep(0.2)