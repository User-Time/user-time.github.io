# 服务机器人访客接待日志数据分析 任务五
import os

def log_analyse():
    log_file = "visitor_raw.log"
    out_file = "visitor_stat.txt"
    valid_data = []
    long_stay_visitor = []

    # 文件读取异常捕获
    try:
        with open(log_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        err_msg = "【异常】visitor_raw.log 文件不存在，无法解析日志\n"
        print(err_msg.strip())
        with open(out_file, "w", encoding="utf-8") as fw:
            fw.write(err_msg)
        return

    # 逐行解析日志
    for line in lines:
        line = line.strip()
        if not line:
            continue
        parts = line.split(",")
        if len(parts) != 4:
            continue
        try:
            visit_time, vid, stay_sec, status = parts
            stay = int(stay_sec)
        except ValueError:
            continue
        # 过滤异常负时长脏数据
        if stay < 0:
            continue
        item = {"time": visit_time, "id": vid, "stay": stay, "status": status}
        valid_data.append(item)
        # 判断长时间停留访客
        if stay > 120:
            long_stay_visitor.append(item)

    # 业务指标统计
    total_cnt = len(valid_data)
    normal_cnt = sum(1 for x in valid_data if x["status"] == "正常接待")
    avg_stay = 0
    if total_cnt > 0:
        sum_stay = sum(x["stay"] for x in valid_data)
        avg_stay = round(sum_stay / total_cnt, 2)

    # 控制台打印摘要
    print("====访客日志统计摘要====")
    print(f"有效访客总数：{total_cnt}")
    print(f"正常接待访客：{normal_cnt}")
    print(f"平均停留时长：{avg_stay} 秒")
    print(f"长时间停留访客数量：{len(long_stay_visitor)}")

    # 输出写入文件
    with open(out_file, "w", encoding="utf-8") as fw:
        fw.write("====访客日志统计结果====\n")
        fw.write(f"有效访客总数：{total_cnt}\n")
        fw.write(f"正常接待访客：{normal_cnt}\n")
        fw.write(f"平均停留时长：{avg_stay} 秒\n")
        fw.write("【重点关注-停留>120s访客】\n")
        for guest in long_stay_visitor:
            fw.write(f"{guest['time']} | {guest['id']} | {guest['stay']}秒 | {guest['status']}\n")

if __name__ == "__main__":
    log_analyse()