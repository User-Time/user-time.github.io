# 导入OpenCV计算机视觉库，用于摄像头采集、图像识别、绘图操作
import cv2

# 创建摄像头捕获对象，参数0代表实验箱默认摄像头设备编号
cap = cv2.VideoCapture(0)
# 设置摄像头输出画面宽度为640像素
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
# 设置摄像头输出画面高度为480像素
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
# 实例化OpenCV内置二维码识别检测器对象
detector = cv2.QRCodeDetector()
# 定义字符串变量，用于缓存最新识别到的二维码解析文本
latest_text = ""

# 开启无限循环，持续读取摄像头实时画面
while True:
    # 读取一帧摄像头图像，ret代表读取是否成功，frame存储画面像素数据
    ret, frame = cap.read()
    # 判断摄像头读取失败的情况
    if not ret:
        # 控制台打印硬件故障提示信息
        print("摄像头读取失败，请检查硬件！")
        # 跳出循环，终止画面采集
        break
    
    # 调用二维码识别函数，返回解析文本、四角浮点坐标、二进制原始数据
    data, pts, _ = detector.detectAndDecode(frame)

    # 判断画面中成功识别到二维码（data不为空字符串）
    if data:
        # 将本次识别的二维码文本存入缓存变量
        latest_text = data
        # 判断二维码坐标数据不为空，避免空数组报错
        if pts is not None:
            # 将浮点型坐标转换为整型，OpenCV绘图仅支持整数像素坐标
            pts_int = pts.astype(int)
            # 在画面上绘制蓝色二维码包围框，线条粗细2
            cv2.polylines(frame, [pts_int[0]], True, (255, 0, 0), 2)
            # 提取二维码左上角X、Y像素坐标
            x_left, y_top = pts_int[0][0][0], pts_int[0][0][1]
            # 在二维码框上方绘制解析出的二维码文字，字体大小0.6，蓝色字体
            cv2.putText(frame, data, (x_left, y_top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
    # 画面无二维码识别结果时执行
    else:
        # 清空二维码文本缓存变量
        latest_text = ""
        # 在画面左上角绘制无二维码提示文字，红色字体
        cv2.putText(frame, "not code", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    
    # 创建名为QRCode Detect的窗口，实时展示处理后的摄像头画面
    cv2.imshow("QRCode Detect", frame)
    # 等待1毫秒监听键盘按键，&0xFF过滤高位数据，获取按键ASCII码
    key = cv2.waitKey(1) & 0xFF

    # 判断是否按下q键（退出按键）
    if key == ord("q"):
        # 控制台打印程序退出提示
        print("程序正常退出")
        # 跳出主循环，结束画面采集
        break
    # 判断是否按下s键（保存按键）
    if key == ord("s"):
        # 将当前窗口画面保存为图片qrcode_detect.png
        cv2.imwrite("qrcode_detect.png", frame)
        # 以写入模式创建文本文件，指定UTF-8编码防止中文乱码
        with open("qrcode_content.txt", "w", encoding="utf-8") as f:
            # 判断缓存内存在二维码文本
            if latest_text != "":
                # 将二维码解析内容写入txt文件
                f.write(latest_text)
                # 控制台打印保存成功与二维码内容
                print("保存成功，二维码内容：", latest_text)
            # 当前画面无二维码的分支处理
            else:
                # 向文本写入无数据提示语句
                f.write("当前未识别到二维码")
                # 控制台打印无识别内容提示
                print("当前无二维码识别内容")

# 释放摄像头硬件设备，关闭图像采集通道
cap.release()
# 销毁所有OpenCV创建的可视化窗口，释放显示资源
cv2.destroyAllWindows()